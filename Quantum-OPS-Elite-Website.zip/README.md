# Quantum OPS Elite — Official Website

Premium technology company website for **Quantum OPS Elite**.

**Positioning:** Digital systems built for businesses that want to operate smarter.

## Tech Stack

- HTML5
- CSS3 (custom design system)
- Vanilla JavaScript
- Supabase (backend / forms / content)
- GitHub + Vercel (deployment)

## Project Structure

```
/
├── index.html
├── css/
│   ├── styles.css          # Design system + base
│   ├── components.css      # Components
│   └── responsive.css      # Media queries
├── js/
│   ├── main.js
│   ├── animations.js
│   ├── forms.js
│   └── supabase.js
├── assets/
│   ├── images/
│   ├── icons/
│   └── videos/
├── robots.txt
└── README.md
```

## Setup

1. The Supabase tables and RLS policies are already configured.
2. Publishable key and project URL are set in `js/supabase.js`.
3. Deploy the entire folder to Vercel (connect GitHub repo).

## Local Preview

You can open `index.html` directly or use a simple static server:

```bash
npx serve .
```

## Features Implemented

- Full design system with exact brand colours
- Sticky responsive navigation + mobile drawer
- Hero with interactive dashboard mock
- Flagship product section
- Interactive live demo modal (sample data)
- Services / What We Build
- Why Quantum OPS pillars
- Portfolio (with clear concept labels)
- Technology stack section
- Academy course cards
- About
- Placeholder testimonials
- FAQ accordion
- Project request form → Supabase `project_requests`
- Floating WhatsApp CTA
- Social links section
- Premium footer
- Scroll progress, fade-up animations, reduced-motion support
- SEO meta tags

## Next Steps (optional)

- Add real screenshots / product images
- Seed courses, testimonials, portfolio via Supabase
- Build protected admin dashboard
- Add individual case-study pages
- Connect real social profile URLs
- Add privacy policy & terms pages

---

**Quantum OPS Elite**  
Build smarter. Operate better.
